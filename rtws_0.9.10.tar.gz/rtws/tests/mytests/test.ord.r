


devtools::reload()

library(rtws)

disconn()

install_rtws()

conn(port = 7891L, clientId = 146L, host="37.24.29.238")
conn(port = 7890L, clientId = 109L, host="37.24.29.238")



## request order id
oid <- reqIds()



## test contract generation and contract_details call
cc  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
cd  <- contractDetails(cc)



cx <- cntr(symbol="BAYN", secType="STK", exchange="SMART",currency = "EUR")
cd <- contractDetails(cx)



c0 = cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
cd <- contractDetails(c0)






## orders
cc   <- cntr(symbol="ACA",localSymbol="ACA",exchange="SMART",primaryExchange="SBF",currency = "EUR",secType="STK")

occ  <- c0
oid  <- reqIds()
ord  <- ordr(orderId=oid,action="SELL",totalQuantity=7L,orderType="MKT",transmit = T)



placeOrder(oid,occ,ord)

x <- rtws:::.read_non_blocking(src="orderstatus")

y <- rtws:::.read_non_blocking(src="openorder")

a <- read.nb(src="orderstatus")
x <- read.nb(src="executions")


cancelOrder(oid)


x <- read_non_blocking(oid)
x

o <- openOrders()
o

y <- completedOrders()



x <- read_blocking(oid)

c1 = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
print(c1)

c2 = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 

c3 = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")

cd = contract_details(c3)
z <- print(cd)



ord = ordr(action="BUY",totalQuantity=1,orderType="MKT",account="gpv")
oid = ord_id()

od <- place_order(oid,c3,ord)

cancel_order(oid)
##

oo <- open_orders()

co <- completed_orders()





