
load("../../x.rdata")
x <- x[[1]]

names(x)

lscnt <- x[, c(3,5,6,7,8,9,13)]
names(lscnt) <- c("conId","symbol","localSymbol",
                  "exchange","primaryExchange","SecType","currency")


lcntrs <- lapply(1:nrow(lscnt), function(x) do.call("cntr", as.list(lscnt[x,])))


i <- 13
cc <- lcntrs[[i]]




hd <- historicalData(cc,"","1 D","5 mins","TRADES","0")





rq <- reticulate::py$reqId$get()
reticulate::py$app$reqHistoricalData(rq,
                                     cc,
                                     "",
                                     "1 D",
                                     "5 mins",
                                     "TRADES",
                                     "0",
                                     1L,F,list())

v <- read_blocking(rq,"historicalData")


read_blocking()

