
devtools::reload()

#detach("package:rtws",unload=T)
library(rtws)

disconn()

install_rtws()

conn(port = 7891L, clientId = 146L, host="37.24.29.238")
conn(port = 7890L, clientId = 161L, host="37.24.29.238")



## request order id
oid <- reqIds()



## test contract generation and contract_details call
c1  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
c2  <- cntr(localSymbol="FXXP MAR 23", exchange = "EUREX", secType="FUT")

c2  <- cntr(symbol="BAYN", secType="STK", exchange="IBIS",currency = "EUR")
c0   = cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
c1   = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
c2   = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 
c3   = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")



x <- histogramData(c1)
a <- rtws:::.read_non_blocking(src="histogramData")

rq <- realTimeBars(c0)

cancelRealTimeBars(102)


a <- rtws:::.read_non_blocking(rq=101,src="realTimeBars")


rq1 <- mktData(c0)
rq2 <- mktData(c1)


b <- rtws:::.read_non_blocking(src="mktData")



c <- rtws:::.read_non_blocking(src="headTimeStamp")


v <- read.nb(src="realTimeBars")


openOrders()
d <- rtws:::.read_non_blocking(src="openOrders")

rq <- lapply(cx,mktData)

cancelMktData(rq2)

rq <- mktData(c1, snapshot=T)
