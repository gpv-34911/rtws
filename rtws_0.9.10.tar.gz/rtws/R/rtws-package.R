#' @keywords internal
"_PACKAGE"

## usethis namespace: start
##'@name .rtws-package
##'@title \strong{A TWS(Trader WorkStation) API for R}
##'@description
##' The rtws package provides an interface for accessing Interactive Brokers’ TWS API from R. Powered by the reticulate package, rtws runs IB’s Python API in a multi-threaded Python environment and facilitates asynchronous communication with IB’s servers.
##'
##'Developed primarily for private use, the package implements only a subset of the functions and callbacks available in the official Python API. However, its structure has been designed to allow for easy extension.
##' 
##' 
##' \strong{Disclaimer}
##' 
##' This library is provided "as is" without any guarantees, whether explicit or implied. The authors disclaim all liability or warranty regarding the software’s information, technology, functionality, or stability. Under no circumstances shall the authors be held responsible for direct or indirect trading losses incurred by relying on this software or its accompanying documentation.
##' Please thoroughly test the software in a simulated (paper) trading environment and always conduct your own analysis before making any investment decisions. None of the materials, including this document and related guides, constitute an offer, solicitation, advertisement, or investment advice. Any examples, strategies, or trading ideas presented are for illustrative and educational purposes only and should not be interpreted as indicators of past or future performance or the likelihood of success of any specific investment or strategy.
##' @details
##'
##' \strong{Installation}
##'
##' - Step 1: Download and Install the Package
##'
##' Download the package’s tar.gz file and install it in R:\cr
##'   `> install.packages(“rtws.nn.nn.nnn.tar.gz”, repos=NULL)`
##'
##'
##' - Step 2: Install reticulate
##'
##' Ensure the reticulate package is installed in R. If not, install it using:\cr
##'   `> install.packages(“reticulate”)`
##'
##' or, as root directly from package management\cr
##'   `$apt install r-cran-reticulate`
##'
##' - Step 3: Install Python and IB Python API
##'
##' Make sure Python 3 and pip3 are installed on your system. On most server platforms, these are pre-installed. If not, refer to the reticulate documentation for troubleshooting.
##'
##' Next, download and install the official IB Python API from Interactive Brokers API. You can download it from
##' `<https://interactivebrokers.github.io/>`. Follow the steps for installation.
##'
##' You will also need to configure your TWS settings, such as port, trusted IP addresses, and API permissions. Detailed instructions are available at
##' <https://www.interactivebrokers.com/campus/ibkr-api-page/twsapi-doc/#tws-settings>
##'
##' - Step 4: Initialize the System
##' 
##' To initialize the system, load the library and connect:
##' ```
##' > library(rtws)
##' > install_rtws()
##' > conn(host = "x.x.x.x", port = 0000L, clientId = 19L, verbose = 1)
##' ```
##' Here, host is the IP address of the machine running TWS, and port is the one configured in TWS settings. If successful, rtws will return:
##'
##' ```Connection ready with oid [int]```
##' \cr
##'  
##' 
##' \strong{Architecture}
##'
##' The library offers three main categories of functions:
##'
##' \strong{Blocking API functions}
##' Blocking functions return requested data immediately. These are suitable for requests involving static information, where asynchronous operations offer little benefit. Examples include:
##' -	\code{\link{reqIds}}
##' -	\code{\link{searchSymbols}}
##' -	\code{\link{accountUpdates}}
##' -	\code{\link{contractDetails}}
##' -	\code{\link{historicalData}}
##' -   \code{\link{L2Exchanges}}
##'
##' \strong{non-blocking API functions}
##' Non-blocking functions leverage asynchronous data exchanges, running the Python API in the background as a thread (similar to a daemon). Data from callbacks is buffered and can be accessed explicitly. Non-blocking functions include:
##' -	\code{\link{realTimeBars}}
##' -	\code{\link{mktData}}
##' -	\code{\link{placeOrder}}
##' -	\code{\link{openOrders}}
##' -   \code{\link{execReport}}
##' 
##' To retrieve buffered data, use:
##' -	\code{\link{read.nb}}
##'
##' Remember that requests persist until explicitly canceled. To prevent overflow, always cancel non-blocking requests and clean up with read.nb after cancellation.
##'
##' \strong{Object preparation functions}
##' These functions create Python objects required for API calls but do not directly interact with TWS.
##' -	\code{\link{cntr}}
##' -	\code{\link{ordr}}
##' -	\code{\link{efltr}}
##' -	\code{\link{pprint}}
##' -	\code{\link{py2list}}
##'
##' 
NULL

## usethis namespace: end

