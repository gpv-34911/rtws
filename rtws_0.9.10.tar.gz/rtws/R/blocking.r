
#############################################################################################
## api helpers blocking api

## Q-Reader

##' read async standard queue
##' @description
##' reads asynchronozed standard queue, which is blocking
##' 
##' @param rq request id of the response to test whether ir matches request
##' @param src source request for matching purposes
##' @return delivers the que element in its structure or shoes error
##' @noRd

.read_blocking <- function(rq=NULL,src=NULL) {
    tmpq <- list()
    r <- list()
    que <- reticulate::py$app$tqr

    while(T) {
        if(que$empty()) {
            Sys.sleep(0.01)
        } else {
            qc <- que$get_nowait()
            if(!is.null(rq))
                if(!any(qc[[1]] %in% rq))  {
                    cat("rq misfit:",unlist(qc),"\n")
                    tmpq[[length(tmpq)+1]] <- qc
                    next
                }
            
            if(qc[[2]] == "error") {
                cat("TWS warn/error:",unlist(qc),"\n")
                
                return()
            }
            
            if(!is.null(src))
                if(!any(qc[[2]] %in% src)) {
                    cat("unexpected source:",unlist(qc),"\n")
                    tmpq[[length(tmpq)+1]] <- qc
                    next
                }

            if(inherits(qc[[3]],"character")) if(qc[[3]] == "end")   break
            r <- c(r,list(qc[[3]]))
        }
    }
    if(length(tmpq)!=0) for(i in 1:length(tmpq)) que$put_nowait(tmpq[[i]])
    r
}



#################################################################################################
## blocking functions

##' @title
##' reqIds - request new order id  --- \strong{blocking}
##' @description
##' Returns the session spanning valid order Id. This is persistent in TWS. Required
##' to identify and dispatch callbacks.
##' @details
##' the orderIds persist in the TWS system. While it would be straightforward to,say, increment the order id after execution when there is a one client submitting orders, it becomes complicaed to ensure appropriate new oderIDs on oe client only.
##' Do not confuse `reqIds` with `reqId`, the latter requests a requestId to track the callbacks on the client side.
##' `reqIds`delivers] the next valid requestId
##' @return valid order ID 
##' @export 

reqIds <- function() {
    reticulate::py$app$reqIds(1L)
    r <- .read_blocking(NULL,"nextValidId")
    if(is.null(r)) return()
    r[[1]]
}



#######################################

##' @title searchSymbols - find symbol and name  --- \strong{blocking}
##' @description
##' searching for contracts 
##' @param searchText search text
##' @return "a list with all contracts that match based on 'symbol', 'localSymbol','longname'search results
##' @details
##' the search looks into IB'hosts fields of symbol, localSymbol, longName and returns each matchin contract 
##' @export 

searchSymbols <- function(searchText) {
    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqMatchingSymbols(rq, searchText)
    r <- .read_blocking(rq,"search")
    cb4src(r,"search")
}


#######################################

##' @title
##' mktDepthExchanges ---  \strong{blocking}
##' @description
##' list all exchanges for which level 2 permissions exist
##' @details
##' immediately returns a list of exchanges and corresponding security types, on which user has level 2 market debth data permissions
##' @return a list of exchanges and security types 
##' @export 

L2Exchanges <- function() {
    reticulate::py$app$reqMktDepthExchanges()
    r <- .read_blocking("","L2Exch")
    cb4src(r,"L2Exch")
}



#######################################

##' @title get contract details   --- \strong{blocking}
##' @description
##' request contract details
##' with sparse data request delivery of contract and associated information
##'
##' This function can be used to look for all contacts that fulfill certain min criteria
##' as suitable contracts. Operates on a list of contracts, too.
##'
##' @param cnt a contract object
##' @return a nested list with contract attributes, contract details and the contract as Python object for contract.details result object. Contracts can be extracted using
##' cntrd2cntr on this. 
##' @examples
##' \dontrun{
##' # one contract returned
##' c1  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
##  cd  <- contractDetails(c1)
##' cd
##'
##' # multiple contracts returned
##' c2  <- cntr(symbol="BAYN", secType="STK", exchange="SMART")
##  cd  <- contractDetails(c2)
##' cd
##' }
##' @export 

contractDetails <- function(cnt) {
    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqContractDetails(rq,cnt)
    r <- .read_blocking(rq=rq,src="contractDetails")
    list(rq, cb4src(r, "contractDetails"))
}




##' @title get historical market data   --- \strong{blocking}
##' @description
##' request historic market data
##' used to obtain historic market data for a security
##'
##' historic data is returned as bar data (open, high, low, close) plus counter of
##' how many transactions occured during the bar period. The bar witdh, duration are
##' defined by the userwithin the limitations of the acount used at IB.
##'
##' @param cnt a contract object
##' @param endDateTime the time and date as (yyyymmdd hh:mm:ss) up to when
##' historic data should be delivered. Defaults to "", meaning up to now.
##' @param durationStr a string specifying the duration from first to last bar, e.g. "3 M"
##' for three months
##' @param barSizeSetting the with of a single bar, starting with one sec "1 sec" 
##' @param whatToShow which data to return, e.g. "TRADES","MIDPOINT","BID",...
##' @param useRTH should data for regular trading hours only be retuned (True, default)
##' @details
##' Some comments on the arguments for this request:
##' endDateTime expects a character formatted "YYYYmmdd HH:MM:SS". durationStr consists of a integer number, then <space> then one of:
##' S (Second(s), D (Day(s)), W (Week(s)), M (Month(s)), Y (Year(s))
##' for example "8 W" for eight weeks.
##' <br>barSizeSettings accepts the following values:
##'
##'1, 5, 10, 15, 30           | secs    |
##'--------------------------:|---------|
##'1, 2, 3, 5, 10, 15, 20, 30 | mins    |
##'1, 2, 3, 4, 8              | hrs     |
##'1                          | days    |
##'1                          | weeks   |
##'1                          | months  |
##'
##' @return returns data frame with the time series
##' @examples
##' \dontrun{
##' 
##' c1  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
##' hd  <- historicalData(c1)
##' hd
##' }
##' @export 
##'

historicalData <- function(cnt,
                           endDateTime = "",
                           durationStr = "10 D",
                           barSizeSetting = "1 hour",
                           whatToShow="TRADES",
                           useRTH="0") {

    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqHistoricalData(rq,
                                         cnt,
                                         endDateTime,
                                         durationStr,
                                         barSizeSetting,
                                         whatToShow,
                                         useRTH,
                                         1L,F,list())


    r <- .read_blocking(rq=rq,src="historicalData")
    list(rq, cb4src(r, "historicalData"))
}


#######################################


##' @title request account status  --- \strong{blocking}
##' @description
##' Request curennt account and securities portfolio status 
##' 
##' @param acct character account name
##' @return returns a list with a) detailed account status and b) the account's securities portfolio positions. 
##' @export 
##' @examples
##' \dontrun{
##' acc <- accountUpdates("<account number or alias>")
##' }

accountUpdates <- function(acct) {
    reticulate::py$app$reqAccountUpdates(TRUE,acct)

    r <- .read_blocking(src=c("account","portfolio"))
    r <- cb4src(r, "account")
}


#######################################


    
