#!/bin/Rscript

##' @title setup rtws environment
##' @name install-and-connect
##' @description
##' `install_rtws' creates a python environment with API functions that can called from R.
##' \cr
##' `conn` starts threaded python processes that are connected to the TWS.
##' \cr
##' `disconn` disconnects threads from TWS and stops them.
##' @details
##' `install_rtws` creates a python environment acessible from R with reticulate. Prepares the environment by importing necessary modules, especially the official IB API, and sources the rtws scripts providing the core functionality
##' Needs to be called just once after the `rtwd` library has been loaded.
##' `conn` starts a background API thread and connects the thread to TWS.
##' `disconn` disconnects threads from TWS and stops them. 
##' @return called for their side-effects
NULL


##' @rdname install-and-connect
##' @param py_env Python virtual env, defaults to "rtws". It is not recommmended to change the parameter. 
##' @export

install_rtws<- function(py_env = "rtws") {
    reticulate::virtualenv_create(py_env)
    reticulate::virtualenv_install(py_env, c("ibapi","typing","pandas"))
    reticulate::use_virtualenv(py_env)

    fp <- system.file("extdata", "rtws.py", package="rtws")
    cat(fp,"\n")
    reticulate::source_python(fp) 

    Sys.setenv(TZ='Europe/Berlin')
    options(useFancyQuotes = FALSE)
    options(stringsAsFactors = FALSE)
    timeDate::setRmetricsOptions("myFinCenter" = "Europe/Berlin")
    timeDate::setRmetricsOptions("max.print"   = "5000")
##    cfg <- reticulate::dict(host="37.24.29.238",port=7891,clientId=71,verbose=TRUE) 
}


                        

#################################################################################################

##' @rdname install-and-connect
##' @param host server on which tws is running, default home
##' @param port port number of tws host, default 7891L 
##' @param clientId Client Id for Tws, default 145L
##' @param verbose verbose level
##' @export

conn <- function(host=NULL, port=NULL, clientId=NULL,verbose=NULL) {
    x <- reticulate::py$cfg$get()
    if(is.null(host)) host <- x$host
    if(is.null(port)) port <- x$port
    if(is.null(clientId)) clientId <- x$clientId
    if(is.null(verbose)) verbose = T
    reticulate::py$cfg$set(host=host,port=port,clientId=clientId,verbose=verbose)

    reticulate::py_run_string("globals()['app'] = start_app()")
}


##' @rdname install-and-connect
##' @export

disconn <- function() {
    reticulate::py$app$disconnect()
}

        
#################################################################################################


##' getReqId - generate new request id
##' @description
##' Request new request iud
##' @return gives a new, unused request id
##' @noRd 
reqId <- function() {
    rqid <- reticulate::py$app$reqId()
}



#################################################################################################


##' @title functions to handle python objects
##' @name object-generation
##' @description
##' `cntr` allows setting up a contrct object
##'  - Any contract attrubute may be given as a named argument (see details). Please refer to IB TWS Api documntation for more information.
##'  - Typically minimum requirements for a valid contract are symbol, the exchange and the secType. There are  however no guarantees.
##' `ordr` create an order object manually
##'  - This function creates an order object from scratch. òrdr` accepts any order attributes, which should be given as named arguments.
##'  - The set of possible attributes of the order object is huge and not listed here. A minimal set or attributes is presented in the details section.
##' `efltr` defines an executionFilter object that is required for execReports requests.
##' 
##' @param ... named atributes of the object
##' 


##' @rdname object-generation
##' @details
##'A Contract can defined by the following attributes that need to be named parameters. Often symbol or localSymbol, exchange and secType are sufficuent. 
##' *   character conId
##' *   character symbol
##' *   character secType
##' *   character lastTradeDateOrContractMonth
##' *   float     strike
##' *   character right
##' *   character multiplier
##' *   character exchange
##' *   character primaryExchange
##' *   character currency
##' *   character localSymbol
##' *   character tradingClass
##' *   character includeExpired
##' *   character secIdType
##' *   character secId
##' *   character description
##' *   character issuerId
##'
##' Alternatively, conractDetails can be user to get all matching contracts.
##' 
##' @return `cntr` returns a contract object 
##' @examples
##' \dontrun{
##' c1 = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
##' c2 = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 
##' c3 = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")
##' }
##' 
##' @export 

cntr <- function(...) reticulate::py$cntr(...)



##' @rdname object-generation
##' @details
##' The IB order object has more than 150 attributes, which cannot be listed here. The read more about the API order object please refer to IB's documentation. However, here is the minimal set of attributes to submitt an order:
##' - self.orderId        required
##' - self.clientId       optional
##' - self.action         BUY or SELL
##' - self.totalQuantity  fload, usually integer
##' - self.orderType      MKT,LMT,STP,...
##' - self.lmtPrice       limit price
##' - self.auxPrice       when order type expects more than one price
##' - self.tif            Time in Force (DAY, GTC, etc.))
##'
##' Please also note, that only a tiny part or the order functionality has been tested. Be extremely careful when using more complex trades or combos in a live trading account.

##' @return `ordr` returns an order object
##' @examples
##' \dontrun{
##' oid  <- reqIds()
##' ord  <- ordr(orderId=oid,action="BUY",totalQuantity=7L,orderType="MKT",transmit = T)
##' }
##' @export 

ordr <- function(...) reticulate::py$ordr(...)



##' @rdname object-generation
##' @details
##' Execution data can be filtered along the following criteria:
##'   - ClientId	int	The API client which placed the order.
##'   - AcctCode	string	The account to which the order was allocated to.
##'   - Time	string	Time from which the executions will be returned yyyymmdd hh:mm:ss Only those executions reported after the specified time will be returned.
##'   - Symbol	string	The instrument’s symbol.
##'   - SecType	string	The Contract’s security’s type (i.e. STK
##'   - Exchange	string	The exchange at which the execution was produced.
##'   - Side	string	The Contract’s side (BUY or SELL)
##' 
##' 
##' @return `efltr` returns an executionFilter object

##' @export 

efltr <- function(...) reticulate::py$ExecFilter(...)




##' transform callbak data
##' @description
##' transforms callback data obtained from the queue into a source and request soecific format.
##' Mainly internally used to process callback data when calling blocking functions.
##' @param r a callback structure as obtained from the queue. 
##' @param src text field denoting the callback functions that have delivered the data
##' @return Returns a more readable and easier processable result data set e.g.
##' including data frames
##' @noRd

cb4src <- function(r,src) {
    if(is.null(r)) return()
    r <- switch(src,
                "search"            = {
                    for (x in r) pprint(x[[1]])
                    lapply(r, function(x) list(contract=x[[1]]$contract,
                                               sectypes=x[[1]]$derivativeSecTypes))
                },

                
                "contractDetails"   = {
                    lapply(r, function(x) list(contract = x[[1]], details = x[[2]], cntr = x[[3]]))
                },
                         

                "historicalData"    = {
                    r <- do.call("rbind.data.frame",lapply(r,function(x) do.call("data.frame", x)))
                    r$dt <- timeDate::timeDate(r$date, "%Y%m%d %H:%M:%S")
                    r$date <- NULL
                    r
                },

                "account"           = {
                    ind <- lapply(r, ncol)==4
                    acc <- do.call("rbind.data.frame",r[ind])
                    pf  <- do.call("rbind.data.frame",r[!ind])
                    list(acc = acc, pf = pf)
                },

                "L2Exch"       = {
                    v <- lapply(unlist(r, recursive=F), function(x) {
                        y <- data.frame(x)
                        names(y) = c("exch","type","listing","service","group")
                        y$group[y$group > 1e8] <- ""
                        y
                    })
                    r <- do.call("rbind.data.frame", v)
                },
                

                "executions"        = {
                    r
                },

                "completedOrders"   = {
                    list(state    = do.call("rbind.data.frame", lapply(r, function(x) x[[1]])),
                         contract = do.call("rbind.data.frame", lapply(r, function(x) x[[2]])),
                         order    = do.call("rbind.data.frame", lapply(r, function(x) x[[3]])))
                }
                )
    r

}



##' @title callback data from non-blocking requests --- \strong{non-blocking}
##' @description
##' Retrieves queued callback data written by callbacks after non-blocking requests. If src is provided, data is transformed to a more readable and processable format specific for each request.
##' 
##' @param rq reqId to use for filter queue data. Not differentiated by rq if NULL.
##' @param src text field denoting the request for which to transform. Not
##' differentiating if NULL. 
##' @return returns accumulated data that was produced by callbacks.
##' @examples
##' \dontrun{
##' cnt <- cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
##' 
##' rid <- realTimeBars(cnt)
##' Sys.sleep(8)
##' cancelRealTimeBars(rid)
##' v1 <- read.nb(src="realTimeBars")
##'
##'
##' rid <- realTimeBars(cnt)
##' Sys.sleep(8)
##' cancelRealTimeBars(rid)
##' v2 <- read.nb(rq=rid)
##' }
##' @export 
read.nb <- function(rq=NULL,src=NULL) {
    r <- .read_non_blocking(rq,src)
    if(is.null(src)) return(r)
    r <- switch(src,
                "realTimeBars"     = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                },


                "mktData"          = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                },

                
                "openorder"         = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                    df$orderId <- sapply(r, function(x) x[[1]])
                    for(c in 2:13) {
                        df[,c] <- as.numeric(df[,c])
                        df[df[,c]>1e10,c] <- 0
                    }
                    df
                },

                
                "orderstatus"       = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                    df$orderId <- sapply(r, function(x) x[[1]])
                    df
                },

                
                "histogramData"    = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                    df <- do.call("rbind.data.frame",regex("[0-9.]+",df[,]))
                    names(df) <- c("price","count")
                    df$reqId <- r[[1]][[1]]
                    df
                },


                "executions"       = {
                    df <- do.call("rbind.data.frame", lapply(r, function(x) as.data.frame(x[[3]])))
                },


                "unknown"          = {
                    "err: non-blocking tag unknown"
                }
                )
    r
}


                

##' @noRd

goof <- function() R6::is.R6(1)
