###############################################################################################

##' Various aliases for easier code writing
##' @param ... Arguments to forward to base function
##' @return Return value(s) of the abbreviated function
##' @name aliases
##' @noRd
NULL

##' @rdname aliases
##' @title
##' .ac coerces to character (short for as.character)
##' @noRd
.ac <- function(...) as.character(...)


##' @rdname aliases
##' @title
##' .an coerces to numeric (short for as.numeric)
##' @noRd

.an <- function(...) as.numeric(...)


##' @rdname aliases
##' @title
##' .dt coerces to timeDate (short for as.timeDate)
##' @noRd

.dt <- function(...) {
    if(is.null(list(...)))
        timeDate::Sys.timeDate() else timeDate::timeDate(..., zone = 'Europe/Berlin')
}


###############################################################################################
## strings

##' String concatenation helper-functions p0 and p9
##' @param ... string/ character elements
##' @return concatenated character elements 
##' @name concat-functions
##' @noRd
NULL



##' @rdname concat-functions
##' @title
##' Function p0 is a short form for paste0
##' @noRd

p0 <- function(...) {
    paste0(...)
}


##' @rdname concat-functions
##' @title
##' p9 returns character string with comma separated elements give as arguments
##' @noRd

p9 <- function(...) p0(..., collapse = ", ")


###############################################################################################



##' @title
##' single quote data.frame
##'
##' @description
##' sQuote.df sets each field of a data.frame in single quotes, typically to enable
##' database inserts
##' 
##' @param df data.frame to be quoted
##' 
##' @return sQuote.df returns a data.frame with every element sQuoted
##' @noRd

sQuote.df <- function(df) {
    for (c in 1:ncol(df)) df[,c] <- sQuote(gsub("'", "`", df[,c]))
    df
}



##' @title
##' Regular expression matching
##' @description
##' regex is a regular expression matching function as one command
##' @param pattern regex pattern
##' @param txt text to be searched
##' @return regex returns the matches (as list)
##' @details regex uses Perl Regular Expressions
##' @noRd
regex <- function(pattern, txt) {
    regmatches(txt, gregexpr(pattern, txt, perl=T))
}



##' string manipulation helpers
##' @name left-and-rightstr
##' @description
##' leftstr and rightstr functions extract nchar characters from a string
##' coming from left or right, respectively.
##' @param x string
##' @param nchar number of characters to be extracted
##' @param inverse logical, if TRUE return string without nchar from the opposite direction
##' @return Return value is a trimmed character
##' @noRd

NULL


##' @rdname left-and-rightstr
##' @title
##' function rightstr
##' @noRd

rightstr <- function(x, nchar, inverse = F) {
    if(! inverse) return(substr(x,nchar(x)-(nchar-1), nchar(x)))
    if(inverse)  return(substr(x, 1, nchar(x) - nchar))
}



##' @rdname left-and-rightstr
##' @title
##' function leftstr
##' @noRd

leftstr <- function(x, nchar, inverse = F) {
    if (! inverse) return(substr(x, 1, nchar))
    if (inverse)  return(substr(x, nchar + 1, nchar(x)))
}



#####################################################################

##' convert python object to list
##' @description
##' basically just for order 
##' 
##' @param l python object
##' 
##' @return python object as list
##' @export

py2list <- function(l) {

    y <- sapply(names(l), function(x) l[[x]])

    rl <- lapply(1:length(y), function(x) {
        cat(names(y)[x],"\n")
        if("decimal.Decimal" %in% class(y[[names(y)[x]]])){
            y[[names(y)[x]]] <- 0L
        } else if( !is.null(y[[names(y)[x]]])&inherits(y[[names(y)[x]]],c("numeric","integer"))) {
            if (y[[names(y)[x]]] > 2e7){
                y[[names(y)[x]]] <- 0L
            }
        } else if (is.environment(y[[names(y)[x]]])) {
            rlx <- py2list(y[[names(y)[x]]])
            return(rlx)
        }
        
        y[[names(y)[x]]]
        
    })
    names(rl) <- names(y)
    rl
}


##' pretty print python objects
##' 
##' @param l python object
##' @param v nested level (internal)
##' @return pretty printed python object
##' @export
pprint <- function(l,v=0) {
    cat("\n")
    y <- sapply(names(l), function(x) l[[x]])
    blnc <- max(nchar(names(l)))+3-nchar(names(y))
    z <- lapply(1:length(y), function(x) {
        if("decimal.Decimal" %in% class(y[[names(y)[x]]])) {
            y[[names(y)[x]]] <- 0
        } else if(is.environment(y[[names(y)[x]]])) {
            cat(names(y)[x],":",sep="")
            pprint(y[[names(y)[x]]],1)
            return()
        }
        
        if(v>0) for(j in 1:v) cat("    ")
        cat(names(y)[x],":",sep="")
        for(i in 1:blnc[x]) {cat(" ")}
        cat(y[[names(y)[x]]],"\n")
    })
}

