
from ibapi.wrapper import EWrapper
from ibapi.client import EClient
from ibapi.order_state import OrderState
from ibapi.order import Order
from ibapi.contract import Contract,ContractDetails
from ibapi.execution import Execution,ExecutionFilter
from ibapi.common import *
from ibapi.ticktype import *
from ibapi.account_summary_tags import AccountSummaryTags

from threading import Thread, Event
from queue import Queue

from time import time as dt
import pandas as pd
import numpy as np
from decimal import Decimal
import math
import sys



################################################################################################

class Cfg:
    def __init__(self):
        self.host      = None
        self.port      = None
        self.clientId  = None
        self.verbose   = 0
        
    def set(self,host="37.24.29.238",port=7891,clientId=71,verbose=True):
        self.host      = host
        self.port      = port
        self.clientId  = clientId
        self.verbose   = verbose
        
    def get(self):
        print(f" Host:    {self.host}     \t \t Port:    {self.port} ")
        print(f" clientId:{self.clientId} \t \t verbose: {self.verbose}")
        return [self.host,self.port,self.clientId,self.verbose]
        
################################################################################################

class ReqId:
    def __init__(self):
        self.rqid = 100
    def get(self):
        self.rqid = self.rqid + 1
        return(self.rqid)

    

################################################################################################
################################################################################################

class ibapp(EClient, EWrapper):
    def __init__(self):
        EClient.__init__(self, self)
        self.ready     = Event()
        self.ready.clear()
        self.tqr       = Queue() 
        self.nbq       = Queue() 
        self.verbose   = cfg.verbose

    ############################################################################################
    def error(self,
              reqId: TickerId,
              errorCode: int,
              errorString: str,
              advancedOrderRejectJson = ""):

        if reqId != -1 and errorCode not in (2176,366):
            qc = (reqId, "error", pd.DataFrame([errorCode, errorString]))
            self.tqr.put_nowait(qc)

            
    ############################################################################################
    ## nextValidId and ready

    def nextValidId(self, orderId: int):
        if self.ready.is_set():
            qc = ("","nextValidId", orderId)
            self.tqr.put_nowait(qc)
            qc = ("","nextValidId", "end")
            self.tqr.put_nowait(qc)
            
        else:
            print(f"  Connection ready with oid '{orderId}'")
            self.ready.set()


    ############################################################################################

    def symbolSamples(self, reqId: int, contractDescriptions: ListOfContractDescription):

        for contractDescription in contractDescriptions:
            derivSecTypes = ""
            for derivSecType in contractDescription.derivativeSecTypes:
                derivSecTypes += " "
                derivSecTypes += derivSecType
                cds = vars(contractDescription)
                qc = (reqId,"search",(contractDescription,derivSecTypes))
                self.tqr.put_nowait(qc)
                

        qc = (reqId,"search","end")
        self.tqr.put_nowait(qc)

    ############################################################################################

    ## contract details
    def contractDetails(self, reqId: int, contractDetails: ContractDetails):
        cd = vars(contractDetails)
        cn0 = cd["contract"]
        del(cd["contract"])
        cn = vars(cn0)
        dfc = pd.DataFrame(cn.values(), index = cn.keys())
        dfd = pd.DataFrame(cd.values(), index = cd.keys())
        qc = (reqId,"contractDetails",(dfc,dfd,cn0))
        self.tqr.put_nowait(qc)

 
    def contractDetailsEnd(self, reqId: int):
        qc = (reqId,"contractDetails","end")
        self.tqr.put_nowait(qc)


    ############################################################################################

    ## bond data
    def bondContractDetails(self, reqId: int, contractDetails: ContractDetails):
        cd = vars(contractDetails)
        cn0 = cd["contract"]
        del(cd["contract"])
        cn = vars(cn0)
        dfc = pd.DataFrame(cn.values(), index = cn.keys())
        dfd = pd.DataFrame(cd.values(), index = cd.keys())
        qc = (reqId,"contractDetails",(dfc,dfd,cn0))
        self.tqr.put_nowait(qc)

    
    ############################################################################################


    ## historical data
    def historicalData(self, reqId: int, bar: BarData):
        v = vars(bar)
        qc = (reqId,"historicalData",v)
        self.tqr.put_nowait(qc)

        
    def historicalDataEnd(self, reqId: int, start: str, end: str):
        qc = (reqId,"historicalData","end")
        self.tqr.put_nowait(qc)

        
    ############################################################################################
        
    def completedOrder(self, contract:Contract, order:Order, orderState:OrderState):

        cntr = vars(contract)
        ord  = vars(order)
        state= vars(orderState)
        c1 = pd.DataFrame(cntr.values(), index = cntr.keys()).T
        o1 = pd.DataFrame(ord.values(), index = ord.keys()).T
        s1 = pd.DataFrame(state.values(), index = state.keys()).T
        qc = ("", "completedOrder",(s1,c1,o1))
        self.tqr.put_nowait(qc)

    def completedOrdersEnd(self):
        qc = ("","completedOrder","end")
        self.tqr.put_nowait(qc)


    ############################################################################################

    ## Account 
    def updateAccountValue(self, key: str, val: str, currency: str, accountName: str):
        b={"acct":accountName,"key":key,"val":val,"currency":currency}
        df = pd.DataFrame(b.values(), index = b.keys()).T
        qc = (accountName,"account",df)
        self.tqr.put_nowait(qc)

    def updatePortfolio(self, contract: Contract, position: Decimal, marketPrice:
                        float, marketValue: float, averageCost: float,
                        unrealizedPNL: float, realizedPNL: float, accountName: str):

        b = {"acct": accountName,
             "position":position,
             "marketPrice":marketPrice,
             "marketValue":marketValue,
             "averageCost":averageCost,
             "unrealizedPNL":unrealizedPNL,
             "realizedPNL":realizedPNL }
        c = vars(contract)
        d = {**b,**c}
        df = pd.DataFrame(d.values(), index = d.keys()).T

        qc = (accountName,"portfolio",df)
        self.tqr.put_nowait(qc)


    def accountDownloadEnd(self, accountName: str):
        qc = (accountName,"account","end")
        self.tqr.put_nowait(qc)
        self.reqAccountUpdates(False,accountName)
        
        

    ############################################################################################

    ## first observation
    def headTimeStamp(self,reqId,headTimeStamp):
        qc = (reqId,"headTimeStamp",[headTimeStamp])
        self.nbq.put_nowait(qc)

    ############################################################################################        
    ## bar data
    def realtimeBar(self,
                    reqId: TickerId,
                    time:int,
                    open_: float,
                    high: float,
                    low: float,
                    close: float,
                    volume:Decimal,
                    wap: Decimal,
                    count: int):
        
        if self.verbose:
            print(reqId,time,open_,high,low,close,volume,wap,count)

        b={"reqId":reqId,"dt":time,"open":open_,"high":high,"low":low,
           "close":close,"vol":volume,"wap":wap,"count":count}
        qc = (reqId,"realTimeBars",b)
        self.nbq.put_nowait(qc)
            

    ############################################################################################

    ## tick data
    def tickPrice(self, reqId: TickerId, tickType: TickType, price: float, attrib: TickAttrib):
        if self.verbose:
            print(reqId,tickType,price,attrib)

        b={"reqId":reqId,"dt":dt(),"tickType":tickType, "value":price}

        df = pd.DataFrame(b.values(), index = b.keys()).T
        qc = (reqId,"mktData",df)
        self.nbq.put_nowait(qc)


    def tickSize(self, reqId: TickerId, tickType: TickType, size: float):
        if self.verbose:
            print(reqId,tickType,size)

        b={"reqId":reqId,"dt":dt(),"tickType":tickType, "value":size}

        df = pd.DataFrame(b.values(), index = b.keys()).T
        qc = (reqId,"mktData",df)
        self.nbq.put_nowait(qc)


    def tickString(self, reqId: TickerId, tickType: TickType, value: str):
        if self.verbose:
            print(reqId,tickType,value)

        b={"reqId":reqId,"dt":dt(),"tickType":tickType, "value":value}

        df = pd.DataFrame(b.values(), index = b.keys()).T
        qc = (reqId,"mktData",df)
        self.nbq.put_nowait(qc)


    def tickGeneric(self, reqId: TickerId, tickType: TickType, value: float):
        if self.verbose:
            print(reqId,tickType,value)

        b={"reqId":reqId,"dt":dt(),"tickType":tickType, "value":value}

        df = pd.DataFrame(b.values(), index = b.keys()).T
        qc = (reqId,"mktData",df)
        self.nbq.put_nowait(qc)


    ############################################################################################
            
    def orderStatus(self, orderId: OrderId, status: str, filled: float,
                    remaining: Decimal, avgFillPrice: float, permId: int,
                    parentId: int, lastFillPrice: float, clientId: int,
                    whyHeld: str, mktCapPrice: float):

        os={"status":status,
            "filled":filled,
            "remaining":remaining,
            "avgFillPrice":avgFillPrice,
            "lastFillprice":lastFillPrice,
            "clientId":clientId,
            "mktCapPrice":mktCapPrice}
        df = pd.DataFrame(os.values(), index = os.keys()).T
        qc = (orderId,"orderstatus",df)
        self.nbq.put_nowait(qc)
        

    ############################################################################################
        
    def openOrder(self, orderId: OrderId, contract: Contract, order: Order,
                  orderState: OrderState):

        ord = vars(order)
        cnt = vars(contract)
        st  = vars(orderState)
        dfo = pd.DataFrame(ord.values(), index = ord.keys()).T
        dfc = pd.DataFrame(cnt.values(), index = cnt.keys()).T
        dfs = pd.DataFrame(st.values(), index = st.keys()).T
        qc  = ("","openorder",(dfs,dfc,dfo))
        self.nbq.put_nowait(qc)

        
    def openOrderEnd(self):
        qc = ("","openorder","end")
        self.nbq.put_nowait(qc)


    ############################################################################################

    def execDetails(self, reqId: int, contract: Contract, execution: Execution):
        ctr = vars(contract)
        exe = vars(execution)
        qc = (reqId,"executions",(exe,ctr))
        self.tqr.put_nowait(qc)
        

    def execDetailsEnd(self, reqId: int):
        qc = (reqId,"executions","end")
        self.tqr.put_nowait(qc)


################################################################################################
################################################################################################

def app_run(app):
    app.run()


def start_app():
    app = ibapp()
    app.connect(cfg.host,cfg.port,cfg.clientId)

    app_thread = Thread(target=app_run, args=(app,), daemon=True)
    app_thread.start()
    
    app.ready.wait()
    return app


################################################################################################

def cntr(**kwargs):
    cntr = Contract()
    for key,value in kwargs.items():
        setattr(cntr, key, value)
    return cntr


################################################################################################

def ordr(**kwargs):
    rder = Order()
    rder.eTradeOnly = ""
    rder.firmQuoteOnly = ""
    for key,value in kwargs.items():
        setattr(rder, key, value)
    return rder


################################################################################################

def ExecFilter(**kwargs):
    eF = ExecutionFilter()
    for key,value in kwargs.items():
        setattr(eF, key, value)
    return eF

################################################################################################




reqId = ReqId()
cfg   = Cfg()



