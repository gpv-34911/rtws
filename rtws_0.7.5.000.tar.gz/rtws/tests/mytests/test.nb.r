
devtools::reload()

#detach("package:rtws",unload=T)
library(rtws)

disconn()

install_rtws()

conn(port = 7891L, clientId = 146L, host="37.24.29.238")
conn(port = 7890L, clientId = 161L, host="37.24.29.238")



## request order id
oid <- reqIds()



## test contract generation and contract_details call
c1  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
c2  <- cntr(localSymbol="FXXP MAR 23", exchange = "EUREX", secType="FUT")

c2  <- cntr(symbol="BAYN", secType="STK", exchange="IBIS",currency = "EUR")
c0   = cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
c1   = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
c2   = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 
c3   = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")

contractDetails(c1)
x <- realTimeBars(c1)

cancelRealTimeBars(x)

v <- read.nb(src="realTimeBars")
y <- read_non_blocking(unlist(x))
y <- read_blocking()
## bars
do.call("rbind.data.frame",lapply(y,function(x) rbind(x)))

cx <- list(c1,c2)


rq <- mktData(c1)


rq <- lapply(cx,mktData)

cancelMktData(rq)

y <- read_non_blocking(unlist(rq))
str(y)

y <- do.call("rbind.data.frame",lapply(y,function(x) as.data.frame(x)))
y)


rq <- headTimeStamp(c0)
cancelHeadTimeStamp(rq)


split(v,v$reqId)
y[1]


read.nb(src="headTimeStamp")


rq <- mktData(c1, snapshot=T)
