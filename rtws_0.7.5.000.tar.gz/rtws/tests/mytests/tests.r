


detach("package:rtws",unload=T)

library(rtws)
disconn()

install_rtws()

#conn(port = 7891L, clientId = 146L, host="37.24.29.238")
conn(port = 7890L, clientId = 161L, host="37.24.29.238")



## request order id
oid <- reqIds()

pprint <- function(l,v=0) {
    cat("\n")
    y <- sapply(names(l), function(x) l[[x]])
    blnc <- max(nchar(names(l)))+3-nchar(names(y))
    z <- lapply(1:length(y), function(x) {
        if("decimal.Decimal" %in% class(y[[names(y)[x]]])) {
            y[[names(y)[x]]] <- 0
        } else if(is.environment(y[[names(y)[x]]])) {
            cat(names(y)[x],":",sep="")
            pprint(y[[names(y)[x]]],1)
            return()
        }
        
        if(v>0) for(j in 1:v) cat("    ")
        cat(names(y)[x],":",sep="")
        for(i in 1:blnc[x]) {cat(" ")}
        cat(y[[names(y)[x]]],"\n")
    })
}


py2list <- function(l) {

    y <- sapply(names(l), function(x) l[[x]])

    rl <- lapply(1:length(y), function(x) {
        cat(names(y)[x],"\n")
        if("decimal.Decimal" %in% class(y[[names(y)[x]]])){
            y[[names(y)[x]]] <- 0L
        } else if( !is.null(y[[names(y)[x]]])&inherits(y[[names(y)[x]]],c("numeric","integer"))) {
            if (y[[names(y)[x]]] > 2e7){
                y[[names(y)[x]]] <- 0L
            }
        } else if (is.environment(y[[names(y)[x]]])) {
            rlx <- py2list(y[[names(y)[x]]])
            y[[names(y)[x]]] <- rlx
        }
        
        y[[names(y)[x]]]
        
    })
    names(rl) <- names(y)
    rl
}


ord2 <- py2list(ord)
do.call("ordr", ord2)


lapply(names(ord2),function(i) if(inherits(ord2[[i]],"numeric")) if( ord2[[i]]> 1e20) ord2[[i]] <- 0L)


## test contract generation and contract_details call
cc  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
cd  <- contractDetails(cc)



cx <- cntr(symbol="BAYN", secType="STK", currency = "EUR")
cd <- contractDetails(cx)



c0 = cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
cd <- contractDetails(c0)




## test historical data request
hd <- historicalData(cc)
tab <- do.call("rbind.data.frame",lapply(hd,rbind))
tab$dt <- timeDate(tab$date, format = "%Y%m%d  %H:%M:%S")




## test account access
acc <- accUpdates("gpv")
acc <- acc_update("U11502291")
acc <- accountUpdate("DU5560681")






rids <- mkt_data(c1)
lapply(reticulate::py$app$queues, function(x) x$empty())
z <- t4r$mktGet()


cancel_mkt_data(rids)



## orders
cc   <- cntr(symbol="ACA",localSymbol="ACA",exchange="SMART",primaryExchange="SBF",currency = "EUR",secType="STK")
oid  <- ord_id()
ord  <- ordr(orderId=oid,action="BUY",totalQuantity=76L,orderType="MKT",transmit = T)

place_order(oid,cc,ord)


lapply(reticulate::py$app$queues, function(x) x$empty())
reticulate::py$app$tqr$empty()

z1 <- t4r$osGet()
z2 <- t4r$ooGet()



oo <- open_orders()

completed_orders()




c1 = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
print(c1)

c2 = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 

c3 = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")

cd = contract_details(c3)
z <- print(cd)



cntrs <- cd2cntr(cd)

cntrd <- cd2cntrd(cd)

cds


ord = ordr(action="BUY",totalQuantity=1,orderType="MKT",account="gpv")
oid = ord_id()

od <- place_order(oid,c3,ord)

cancel_order(oid)
##

oo <- open_orders()

co <- completed_orders()

a <- mkt_data(c3)
a <- mkt_data(cntrs)

acc <- acc_update("DU4460681")
acc




