

disconn()
devtools::reload()
library(rtws)
install_rtws()


##conn(port = 7891L, clientId = 146L, host="37.24.29.238")
conn(port = 7890L, clientId = 14L, host="37.24.29.238")



## request order id
oid <- reqIds()



## test contract generation and contract_details call
cc  <- cntr(symbol="ES", localSymbol="ESH5", exchange = "CME", secType="FUT")
cd  <- contractDetails(cc)



cx <- cntr(symbol="BAYN", secType="STK", currency = "EUR")
cd <- contractDetails(cx)


cnt <- cntr(symbol="SIE", secType="STK", currency = "EUR", exchange="SMART")



c0 = cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
cd <- contractDetails(c0)


c1 = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")

c2 = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 

c3 = cntr(localSymbol = "ESZ4", exchange = "CME", secType="FUT")




ef <- execFilt(time="2025-01-01 00:00:00")
z <- execs(ef)


## test historical data request
hd <- historicalData(cc)
tab <- do.call("rbind.data.frame",lapply(hd,rbind))
tab$dt <- timeDate(tab$date, format = "%Y%m%d  %H:%M:%S")




## test account access

acc <- accountUpdates("gpv")
acc


ss <- searchSymbols("Deutsche")
a <- lapply(ss, function(x) x$contract)
pprint(a[[1]])
ss


