    
#############################################################################################
## api helpers non-blocking

##' read async non-blocking queues
##' @description
##' reads asynchronozed non-blocking queue - invoked manually
##' 
##' @param rq request id of the response to test whether ir matches request
##' @param src source request for matching purposes
##' @return delivers the que element in its structure or shoes error
##' @noRd

.read_non_blocking <- function(rq=NULL,src=NULL) {

    r <- list()
    que <- reticulate::py$app$nbq

    n <- que$qsize()
    if(n!=0) {
        for(k in 1:n) {
            qc <- que$get_nowait()
            if(!is.null(rq))
                if(!any(qc[[1]]%in%rq))    {que$put_nowait(qc) ; next }
            if(qc[[2]] == "error") {cat("error:", unlist(qc),"\n"); next }
            if(!is.null(src))
                if(!any(qc[[2]]%in%src))   {que$put_nowait(qc) ; next }
            if(inherits(qc[[3]],"character")) if(qc[[3]] == "end") next
            r <- c(r,list(qc[[3]]))
        }
    }

    que <- reticulate::py$app$tqr
    n <- que$qsize()
    if(n==0) return(r)
    for(k in 1:n) {
        qc <- que$get_nowait()
        if(qc[[2]] == "error") {cat("error:", unlist(qc),"\n"); next }
        que$put_nowait(qc) 
    }
    r
}



#################################################################################################
## non-blocking functions
##
#################################################################################################

##' @title head timestamp request  --- \strong{non-blocking}
##' @name head-timestamp
##' @description
##' Request/cancel headTimeStamp subscriptions
##' @details
##' IB has implemented the headTimeStamp request as subscription. For the moment it was kept this way, although it is difficult imagining a realistic use-case, which would benefit from this design choice. This function might be changed to blocking in some time, so please use with care.
##' 
NULL

##' @rdname head-timestamp
##' 
##' @param cnt list with a contract object
##' @param whatToShow whatToShow, e.g. "TRADES", "MIDPOINT", "ASK", ...
##' @param useRTH looks only within regular trading hours
##' @return headTimeStamp returns the earliest observation timestamp for the contract under the specified conditions
##' @export 

headTimeStamp <- function(cnt,whatToShow="TRADES",useRTH=0L) {
    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqHeadTimeStamp(rq, cnt, whatToShow, useRTH, 1L)
    rq
}


##' @rdname head-timestamp
##' @param reqids request ids used for subscription
##' @export 

cancelHeadTimeStamp <- function(reqids) {
    lapply(reqids, function(x) reticulate::py$app$cancelHeadTimeStamp(as.integer(x)))
}
           
           
#################################################################################################
## realtime-bars

##' @title
##' Request/ cancel five second live bar data --- \strong{non-blocking}
##' @name realtime-bars
##' @description
##' Request/cancel live 5 sec bar data subscription
##'
##' @examples
##' \dontrun{
##' cnt <- cntr(symbol="NVDA",exchange="SMART",secType="STK",currency="USD")
##'
##' rid <- realTimeBars(cnt)
##' Sys.sleep(8)
##' v1 <- read.nb(src="realTimeBars")
##' Sys.sleep(8)
##' cancelRealTimeBars(rid)
##' v2 <- read.nb(src="realTimeBars")
##' }
NULL


##' @rdname realtime-bars
##' @details
##' `realTimeBars` requests live bar data for a contract while `cancelRealTimeBars` stops the subscription. 
##' @param cnt contract object
##' @param barSize for future use; currently only 5sec bars are accepted
##' @param whatToShow whatToShow, e.g. "TRADES", "MIDPOINT", "ASK", ...
##' @param useRTH show bars within regular trading hours only
##' @return realTimeBars returns the reqId, which is needed to cancel the request later. 
##' @export 

realTimeBars <- function(cnt,
                         barSize=5L,
                         whatToShow="TRADES",
                         useRTH="0") {

    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqRealTimeBars(rq,
                                       cnt,
                                       barSize,
                                       whatToShow,
                                       useRTH,
                                       list())
    rq
}



##' @rdname realtime-bars
##' @param reqids  request IDs from subscription
##' @export 

cancelRealTimeBars <- function(reqids) {
    lapply(reqids, function(x) reticulate::py$app$cancelRealTimeBars(as.integer(x)))
}


#################################################################################################


##' @title
##' Request tick data and cancel tick-data subscriptions  --- \strong{non-blocking}
##' @name mkt-tick-data
##' @description
##' `mkdData` requests a subscription to tick data, 'cancelMktData' cancels a subscription 
##' @details
##' `mktData` requests tick data for a single instrument. However, often more than one security needs to be monitored. This can be achieved by successively calling this function, see examples.
##' `cancelMktData` accepts a list of reqids.
##' 
##'@examples
##'\dontrun{
##' c1   = cntr(symbol="AAPL",exchange="SMART",secType="STK",currency="USD")
##' ## snapshot
##' rq <- mktData(c1, "snapshot")
##' Sys.sleep(1)
##' snap <- read.nb(rq = rq)
##'
##' ## multiple securities
##' ## Since the call is non-blocking, it returns immediately. Calling `read.nb`
##' ## at any later point in time will return the accumulated ticks as `data.frame`.
##' ## Note that reqids and contracts have the same ordering, thus each reqId 
##' ## references a one contract.The resulting data.frame therefore includes a column
##' ## with the reqIds allowing to map the contract to the data. 
##'
##' c2   = cntr(symbol="EUR",currency="USD",secType="CASH",exchange="IDEALPRO") 
##' reqids <- lapply(list(c1,c2), mktData)
##' Sys.sleep(5)
##' cancelMktData(reqids)
##' tcks <- read.nb(unlist(reqids))
##' }
##' @return dataframe with ticks and maching reqId
##' 

NULL



## mkt-data

##' @rdname mkt-tick-data
##' @param cnt a contract object
##' @param genTickTypes  optional list of one or more aditional generic ticks
##' @param snapshot - only one-time current data for security (no cancelMktData required)
##' 
##' @export 

mktData <- function(cnt,genTickTypes = "",snapshot=F) {
    rq <- reticulate::py$reqId$get()
    reticulate::py$app$reqMktData(rq,cnt,genTickTypes,snapshot,F,list())
    rq
}


##' @rdname mkt-tick-data
##' @param reqids request ids to cancel
##' @export 
##' 

cancelMktData <- function(reqids) {
    lapply(reqids, function(x) reticulate::py$app$cancelMktData(x))
}


##################################################################################################

##' @title
##' placing, cancelling, updating and reporting orders 
##' @name order-management
##' @order 1
##' @description
##' `placeOrder` submitts an order to a specified exchange or changes a submitted order --- \strong{nin-blocking}
##' \cr
##' `cancelOrder` discards an open order --- \strong{non-blocking}
##' \cr
##' `openOrder` gives an overview of currently open orders --- \strong{non blocking}
##' \cr
##' `completedOrders` lists all orders that recently were completed --- \strong{blocking}
##' \cr
##' `execReport` reports executed orders, commissions and more --- \strong{blocking}
##' 
##' @details
##' `placeOrder` submits a specific order to an exchange. After submission the callback 'open order' and 'order status' send status information until the order has been filled, canceled or not accepted. The order status can be accessed with `read.nb`. `placeOrder` is also used to change an open order.
##' \cr
##' 'cancelOrder' discards an open order.
##' \cr
##' `openOrder` requests information about open orders in the same way that `placeOrder` through the callbacks 'open order' and 'order status'.
##' \cr
##' `execReport` creates a report of executed orders differentiated along the criteria defined in the `efltr` object that is given to the function as argument.
##' \cr
##' `completedOrders` provides all completed orders for the current client id only
##' @return
##' `placeOrder`, `cancelOrder`, `openOrder` are called for their side-effects only.
##' \cr
##' `execReport`, `completedOrders` returns (potentially) filtered list of executed orders.
 
NULL


##' @rdname order-management
##' @param orderId is a unique identifier to track for callbacks and reporting obtaineed by `reqIds()`
##' @param cnt contract object defining the instrument and exchange
##' @param ord order object detailling the order parameters
##' @order 2
##' @export 
##' 

placeOrder <- function(orderId, cnt, ord) 
    reticulate::py$app$placeOrder(orderId,cnt,ord)


##' @rdname order-management
##' @param orderId is a unique identifier to track for callbacks and reporting obtaineed by `reqIds()`
##' @order 3
##' @export 
##' 

cancelOrder <- function(orderId)
    reticulate::py$app$cancelOrder(orderId)


##' @rdname order-management
##' @order 4
##' @export 
##' 

openOrders <- function()
    reticulate::py$app$reqOpenOrders()




#################################################################################################


